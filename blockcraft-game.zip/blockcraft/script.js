const THREE = window.THREE;

// BLOCKCRAFT — original browser voxel sandbox. Three.js is loaded from a public CDN.
const $ = (id) => document.getElementById(id);
const ui = {
  view: $('game-view'), loading: $('loading-screen'), loadingBar: $('loading-bar'), loadingText: $('loading-text'),
  menu: $('main-menu'), hud: $('hud'), play: $('play-button'), cont: $('continue-button'), controls: $('controls-button'),
  controlsCard: $('controls-card'), closeControls: $('close-controls'), mobileStart: $('mobile-start'), mobileStartButton: $('mobile-start-button'),
  hotbar: $('hotbar'), inventory: $('inventory-panel'), inventoryGrid: $('inventory-grid'), pause: $('pause-panel'),
  target: $('target-name'), healthValue: $('health-value'), hungerValue: $('hunger-value'), healthMeter: $('health-meter'), hungerMeter: $('hunger-meter'),
  day: $('day-label'), time: $('time-label'), pos: $('position-label'), toast: $('toast'), saveStatus: $('save-status'),
};

const BLOCKS = {
  grass:  {name:'Grass', color:'#6eaa45', top:'#70b64d', side:'#795b39', icon:'🟩'},
  dirt:   {name:'Dirt', color:'#8b633e', icon:'🟫'},
  stone:  {name:'Stone', color:'#858b8b', icon:'⬜'},
  wood:   {name:'Log', color:'#90613b', icon:'🪵'},
  leaves: {name:'Leaves', color:'#4e8b42', icon:'🌿'},
  sand:   {name:'Sand', color:'#d9c27d', icon:'🟨'},
  planks: {name:'Planks', color:'#bd8a50', icon:'🟧'},
  brick:  {name:'Brick', color:'#a55f4e', icon:'🟥'},
  glass:  {name:'Glass', color:'#9bd9df', icon:'🔹'},
  bedrock:{name:'Bedrock', color:'#363b3d', icon:'⬛'},
};
const HOTBAR = ['grass','dirt','stone','wood','planks','leaves','sand','brick','glass'];
const SAVE_KEY = 'blockcraft_world_v1';
const WORLD_SIZE = 28;
const EYE_HEIGHT = 1.62;
const PLAYER_RADIUS = 0.27;
const WORLD_LIMIT = WORLD_SIZE / 2 + 5;

let scene, camera, renderer, clock, raycaster, blockGroup, water, sunLight, ambientLight, outline;
let world = new Map();
let meshes = [];
let seed = Math.floor(Math.random() * 999999);
let player = {x:0.5, y:8, z:0.5, vy:0, yaw:0, pitch:0, health:20, hunger:20, grounded:false};
let inventory = {grass:32,dirt:64,stone:64,wood:24,leaves:32,sand:20,planks:24,brick:12,glass:12,apple:3};
let selectedSlot = 0;
let running = false, paused = false, pointerLocked = false, worldReady = false;
let dayClock = 0.33, dayNumber = 1, hungerClock = 0, saveClock = 0, toastTimer = 0;
let currentTarget = null;
const keys = Object.create(null);
const moveTouch = Object.create(null);
let mobileLook = null;

const keyOf = (x,y,z) => `${x},${y},${z}`;
function hash2(x,z,s=seed){let n=Math.sin(x*127.1+z*311.7+s*0.013)*43758.5453;return n-Math.floor(n)}
function heightAt(x,z){
  const broad=Math.sin((x+seed%17)*0.22)*1.15+Math.cos((z-seed%13)*0.19)*1.05;
  const detail=(hash2(x,z)-.5)*1.8;
  return Math.max(3,Math.floor(5+broad+detail));
}
function setBlock(x,y,z,type){
  if(y<0||y>36||Math.abs(x)>WORLD_LIMIT||Math.abs(z)>WORLD_LIMIT)return;
  world.set(keyOf(x,y,z),type);
}
function removeBlock(x,y,z){world.delete(keyOf(x,y,z));}
function getBlock(x,y,z){return world.get(keyOf(x,y,z));}
function highestAt(x,z){
  const ix=Math.floor(x), iz=Math.floor(z);
  for(let y=35;y>=0;y--) if(getBlock(ix,y,iz)) return y;
  return -1;
}
function seededInt(x,z,min,max){return min+Math.floor(hash2(x,z,seed+99)*(max-min+1));}
function generateWorld(){
  world.clear();
  const half=Math.floor(WORLD_SIZE/2);
  for(let x=-half;x<half;x++){
    for(let z=-half;z<half;z++){
      const h=heightAt(x,z);
      for(let y=0;y<=h;y++){
        let type='stone';
        if(y===0)type='bedrock';
        else if(y===h)type=(h<=4?'sand':'grass');
        else if(y>=h-3)type=(h<=4?'sand':'dirt');
        setBlock(x,y,z,type);
      }
      // A shallow shoreline and occasional sand patches.
      if(h<=4)for(let y=1;y<=h;y++)setBlock(x,y,z,'sand');
      if(hash2(x+37,z-81)<.018 && h>4)setBlock(x,h,z,'sand');
    }
  }
  // Small, scattered blocky trees.
  for(let x=-half+2;x<half-2;x++)for(let z=-half+2;z<half-2;z++){
    if(hash2(x*3+18,z*3-7)<.965)continue;
    const h=heightAt(x,z);
    if(h<5)continue;
    const trunk=3+seededInt(x,z,0,2);
    for(let y=1;y<=trunk;y++)setBlock(x,h+y,z,'wood');
    const crownY=h+trunk;
    for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++)for(let dy=-1;dy<=2;dy++){
      const distance=Math.abs(dx)+Math.abs(dz)+Math.max(0,dy)*.65;
      if(distance<=3.25 && !(dx===0&&dz===0&&dy<1)){
        if(!getBlock(x+dx,crownY+dy,z+dz))setBlock(x+dx,crownY+dy,z+dz,'leaves');
      }
    }
  }
}

function makePixelTexture(base, speckle, count=42, side=false){
  const canvas=document.createElement('canvas');canvas.width=canvas.height=16;
  const ctx=canvas.getContext('2d');ctx.fillStyle=base;ctx.fillRect(0,0,16,16);
  if(side){ctx.fillStyle='#70ad48';ctx.fillRect(0,0,16,4);ctx.fillStyle='#5b963d';ctx.fillRect(0,4,16,1);}
  let n=seed+base.length*13;
  const rand=()=>{n=(n*1664525+1013904223)>>>0;return n/4294967296;};
  for(let i=0;i<count;i++){
    ctx.globalAlpha=.18+rand()*.35;ctx.fillStyle=speckle;
    const size=rand()>.82?2:1;ctx.fillRect(Math.floor(rand()*16),Math.floor(rand()*16),size,size);
  }
  ctx.globalAlpha=1;
  const tex=new THREE.CanvasTexture(canvas);tex.magFilter=THREE.NearestFilter;tex.minFilter=THREE.NearestMipmapNearestFilter;tex.colorSpace=THREE.SRGBColorSpace;return tex;
}
function makeMaterials(){
  const tex={
    grassTop:makePixelTexture('#70ad48','#b2d77a',34),grassSide:makePixelTexture('#805b39','#b68a55',35,true),
    dirt:makePixelTexture('#805b39','#bd8a55',45),stone:makePixelTexture('#818887','#c3c8c3',55),
    wood:makePixelTexture('#96633c','#d1a06b',40),leaves:makePixelTexture('#4e873e','#9ac65e',52),
    sand:makePixelTexture('#d7c17e','#f1dfa3',42),planks:makePixelTexture('#bd8a50','#e3b977',35),
    brick:makePixelTexture('#a65e4d','#d18a70',42),glass:makePixelTexture('#a7dfe0','#efffff',15),bedrock:makePixelTexture('#343b3d','#626a6b',50),
  };
  const mat=(t,extra={})=>new THREE.MeshLambertMaterial({map:t,...extra});
  return {
    grass:[mat(tex.grassSide),mat(tex.grassSide),mat(tex.grassTop),mat(tex.dirt),mat(tex.grassSide),mat(tex.grassSide)],
    dirt:mat(tex.dirt),stone:mat(tex.stone),wood:mat(tex.wood),leaves:mat(tex.leaves,{transparent:true,alphaTest:.15}),
    sand:mat(tex.sand),planks:mat(tex.planks),brick:mat(tex.brick),glass:mat(tex.glass,{transparent:true,opacity:.62}),bedrock:mat(tex.bedrock),
  };
}
let materials;
function rebuildInstances(){
  while(blockGroup.children.length)blockGroup.remove(blockGroup.children[0]);
  meshes=[];
  const buckets={};
  for(const [key,type] of world){if(!buckets[type])buckets[type]=[];const [x,y,z]=key.split(',').map(Number);buckets[type].push({x,y,z});}
  const dummy=new THREE.Object3D();
  for(const [type,positions] of Object.entries(buckets)){
    const mesh=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),materials[type],positions.length);
    mesh.userData.blockType=type;mesh.userData.positions=positions;mesh.castShadow=true;mesh.receiveShadow=true;
    positions.forEach((p,i)=>{dummy.position.set(p.x+.5,p.y+.5,p.z+.5);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});
    mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingSphere();blockGroup.add(mesh);meshes.push(mesh);
  }
}

function setupScene(){
  scene=new THREE.Scene();scene.background=new THREE.Color('#87c5ed');scene.fog=new THREE.Fog('#87c5ed',24,62);
  camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.1,120);camera.rotation.order='YXZ';
  renderer=new THREE.WebGLRenderer({antialias:false,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;ui.view.appendChild(renderer.domElement);
  clock=new THREE.Clock();raycaster=new THREE.Raycaster();raycaster.far=6;
  blockGroup=new THREE.Group();scene.add(blockGroup);
  materials=makeMaterials();
  ambientLight=new THREE.HemisphereLight(0xd9efff,0x78694d,1.35);scene.add(ambientLight);
  sunLight=new THREE.DirectionalLight(0xfff0cf,2.2);sunLight.position.set(-25,38,-18);sunLight.castShadow=true;sunLight.shadow.mapSize.set(1024,1024);sunLight.shadow.camera.left=-30;sunLight.shadow.camera.right=30;sunLight.shadow.camera.top=30;sunLight.shadow.camera.bottom=-30;scene.add(sunLight);
  water=new THREE.Mesh(new THREE.PlaneGeometry(160,160),new THREE.MeshPhongMaterial({color:0x4b9fb3,transparent:true,opacity:.55,shininess:80,side:THREE.DoubleSide}));water.rotation.x=-Math.PI/2;water.position.y=3.85;scene.add(water);
  const outlineGeo=new THREE.EdgesGeometry(new THREE.BoxGeometry(1.006,1.006,1.006));outline=new THREE.LineSegments(outlineGeo,new THREE.LineBasicMaterial({color:0x17221a,linewidth:2}));outline.visible=false;scene.add(outline);
  window.addEventListener('resize',onResize);
  renderer.domElement.addEventListener('contextmenu',e=>e.preventDefault());
  renderer.domElement.addEventListener('mousedown',onMouseDown);
  renderer.domElement.addEventListener('pointerdown',onTouchDown);
  renderer.domElement.addEventListener('pointermove',onTouchMove);
  renderer.domElement.addEventListener('pointerup',onTouchUp);
  renderer.domElement.addEventListener('wheel',onWheel,{passive:false});
  document.addEventListener('pointerlockchange',()=>{pointerLocked=document.pointerLockElement===renderer.domElement;});
  document.addEventListener('mousemove',onMouseMove);
  document.addEventListener('keydown',onKeyDown);document.addEventListener('keyup',e=>{keys[e.code]=false;});
  bindButtons();
}
function onResize(){if(!camera||!renderer)return;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);}
function isTouchDevice(){return matchMedia('(pointer: coarse)').matches||navigator.maxTouchPoints>0;}
function setLoading(pct,msg){ui.loadingBar.style.width=`${pct}%`;if(msg)ui.loadingText.textContent=msg;}
function startNewWorld(){
  seed=Math.floor(Math.random()*999999);inventory={grass:32,dirt:64,stone:64,wood:24,leaves:32,sand:20,planks:24,brick:12,glass:12,apple:3};
  player={x:.5,y:10,z:.5,vy:0,yaw:0,pitch:0,health:20,hunger:20,grounded:false};dayClock=.33;dayNumber=1;hungerClock=0;
  bootWorld(false);
}
function loadWorld(){
  let data=null;try{data=JSON.parse(localStorage.getItem(SAVE_KEY)||'null');}catch(e){console.warn('Save could not be read',e);}
  if(!data){showToast('No saved world yet');return;}
  seed=data.seed||seed;world=new Map(data.blocks||[]);inventory={...inventory,...(data.inventory||{})};player={...player,...(data.player||{})};dayClock=data.dayClock??.33;dayNumber=data.dayNumber||1;
  bootWorld(true);
}
function bootWorld(fromSave){
  ui.menu.classList.add('hidden');ui.loading.classList.remove('hidden');ui.hud.classList.add('hidden');ui.mobileStart.classList.add('hidden');
  setLoading(5,fromSave?'Loading your world…':'Generating terrain…');
  setTimeout(()=>{
    if(!fromSave){generateWorld();}
    setLoading(53,'Adding trees and block textures…');
    rebuildInstances();
    const ground=highestAt(player.x,player.z);player.y=Math.max(player.y,ground+1+EYE_HEIGHT);player.vy=0;
    camera.position.set(player.x,player.y,player.z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
    updateHotbar();updateStats();updateInventory();
    setLoading(100,'Ready!');
    setTimeout(()=>{
      ui.loading.classList.add('hidden');ui.hud.classList.remove('hidden');running=true;paused=false;worldReady=true;clock.getDelta();
      if(isTouchDevice()){ui.mobileStart.classList.remove('hidden');ui.mobileStartButton.textContent='Tap to look around';}
      else renderer.domElement.requestPointerLock?.();
      showToast(fromSave?'World loaded':'World created — have fun!');
      animate();
    },180);
  },40);
}
function saveWorld(){
  if(!worldReady)return;
  const data={version:1,seed,blocks:[...world.entries()],inventory,player:{x:player.x,y:player.y,z:player.z,yaw:player.yaw,pitch:player.pitch,health:player.health,hunger:player.hunger},dayClock,dayNumber};
  try{localStorage.setItem(SAVE_KEY,JSON.stringify(data));ui.saveStatus.textContent='Saved on this device ✓';showToast('World saved');}
  catch(e){ui.saveStatus.textContent='Could not save — device storage may be full.';showToast('Save failed');console.error(e);}
}

function bindButtons(){
  ui.play.addEventListener('click',startNewWorld);ui.cont.addEventListener('click',loadWorld);
  ui.controls.addEventListener('click',()=>ui.controlsCard.classList.remove('hidden'));ui.closeControls.addEventListener('click',()=>ui.controlsCard.classList.add('hidden'));
  $('resume-button').addEventListener('click',resumeGame);$('save-button').addEventListener('click',saveWorld);$('menu-button').addEventListener('click',exitToMenu);
  $('close-inventory').addEventListener('click',closeInventory);
  $('craft-planks').addEventListener('click',()=>craft('planks',1,4));$('craft-bricks').addEventListener('click',()=>craft('brick',2,4));
  ui.mobileStartButton.addEventListener('click',()=>{ui.mobileStart.classList.add('hidden');showToast('Drag across the world to look around');});
  $('mobile-mine').addEventListener('pointerdown',e=>{e.preventDefault();mineBlock();});$('mobile-place').addEventListener('pointerdown',e=>{e.preventDefault();placeBlock();});$('mobile-jump').addEventListener('pointerdown',e=>{e.preventDefault();keys.Space=true;setTimeout(()=>keys.Space=false,180);});
  document.querySelectorAll('[data-move]').forEach(btn=>{
    const k=btn.dataset.move;const down=e=>{e.preventDefault();moveTouch[k]=true;};const up=e=>{e.preventDefault();moveTouch[k]=false;};
    btn.addEventListener('pointerdown',down);btn.addEventListener('pointerup',up);btn.addEventListener('pointercancel',up);btn.addEventListener('pointerleave',up);
  });
  updateContinueButton();
}
function updateContinueButton(){try{ui.cont.disabled=!localStorage.getItem(SAVE_KEY);ui.cont.style.opacity=ui.cont.disabled?'.48':'1';}catch(e){ui.cont.disabled=true;}}
function exitToMenu(){saveWorld();running=false;paused=true;worldReady=false;document.exitPointerLock?.();ui.hud.classList.add('hidden');ui.menu.classList.remove('hidden');ui.inventory.classList.add('hidden');ui.pause.classList.add('hidden');updateContinueButton();}
function pauseGame(show=true){if(!running)return;paused=true;ui.pause.classList.remove('hidden');ui.inventory.classList.add('hidden');document.exitPointerLock?.();}
function resumeGame(){paused=false;ui.pause.classList.add('hidden');if(!isTouchDevice())renderer.domElement.requestPointerLock?.();}
function openInventory(){if(!running||paused)return;ui.inventory.classList.remove('hidden');document.exitPointerLock?.();updateInventory();}
function closeInventory(){ui.inventory.classList.add('hidden');if(running&&!paused&&!isTouchDevice())renderer.domElement.requestPointerLock?.();}
function onKeyDown(e){
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();keys[e.code]=true;
  if(!running)return;
  if(e.code==='Escape'){if(!ui.inventory.classList.contains('hidden'))closeInventory();else if(!paused)pauseGame();else resumeGame();}
  if(e.code==='KeyE'){if(ui.inventory.classList.contains('hidden'))openInventory();else closeInventory();}
  if(e.code==='Space'&&player.grounded&&!paused){player.vy=7.2;player.grounded=false;}
  if(/^Digit[1-9]$/.test(e.code)){selectedSlot=Number(e.code.slice(5))-1;updateHotbar();}
}
function onMouseMove(e){if(!running||paused||!pointerLocked)return;player.yaw-=e.movementX*.0022;player.pitch-=e.movementY*.0022;player.pitch=THREE.MathUtils.clamp(player.pitch,-Math.PI/2+.03,Math.PI/2-.03);}
function onMouseDown(e){if(!running||paused)return;if(!pointerLocked){if(!isTouchDevice())renderer.domElement.requestPointerLock?.();return;}if(e.button===0)mineBlock();if(e.button===2)placeBlock();}
function onWheel(e){if(!running||paused)return;e.preventDefault();selectedSlot=(selectedSlot+(e.deltaY>0?1:8))%9;updateHotbar();}
function onTouchDown(e){
  if(!isTouchDevice()||!running||paused||e.pointerType!=='touch')return;
  if(e.target.closest?.('#mobile-controls'))return;
  mobileLook={id:e.pointerId,x:e.clientX,y:e.clientY};
  renderer.domElement.setPointerCapture?.(e.pointerId);
}
function onTouchMove(e){if(!mobileLook||e.pointerId!==mobileLook.id)return;const dx=e.clientX-mobileLook.x,dy=e.clientY-mobileLook.y;player.yaw-=dx*.005;player.pitch-=dy*.005;player.pitch=THREE.MathUtils.clamp(player.pitch,-1.45,1.45);mobileLook.x=e.clientX;mobileLook.y=e.clientY;}
function onTouchUp(e){if(mobileLook&&e.pointerId===mobileLook.id)mobileLook=null;}
function getMoveVector(){
  let forward=(keys.KeyW||keys.ArrowUp||moveTouch.forward?1:0)-(keys.KeyS||keys.ArrowDown||moveTouch.back?1:0);
  let strafe=(keys.KeyD||keys.ArrowRight||moveTouch.right?1:0)-(keys.KeyA||keys.ArrowLeft||moveTouch.left?1:0);
  const len=Math.hypot(forward,strafe)||1;forward/=len;strafe/=len;
  return {forward,strafe};
}
function canStandAt(x,z,feetY){
  const offsets=[[-PLAYER_RADIUS,-PLAYER_RADIUS],[PLAYER_RADIUS,-PLAYER_RADIUS],[-PLAYER_RADIUS,PLAYER_RADIUS],[PLAYER_RADIUS,PLAYER_RADIUS]];
  for(const [ox,oz] of offsets){const top=highestAt(x+ox,z+oz)+1;if(feetY<top-.03)return false;}
  return true;
}
function updatePlayer(dt){
  const {forward,strafe}=getMoveVector();const sprint=keys.ShiftLeft||keys.ShiftRight;const speed=sprint?7.1:4.5;
  const sin=Math.sin(player.yaw),cos=Math.cos(player.yaw);
  const dx=(strafe*cos-forward*sin)*speed*dt;const dz=(-strafe*sin-forward*cos)*speed*dt;
  let nx=THREE.MathUtils.clamp(player.x+dx,-WORLD_LIMIT,WORLD_LIMIT),nz=THREE.MathUtils.clamp(player.z+dz,-WORLD_LIMIT,WORLD_LIMIT);
  const feet=player.y-EYE_HEIGHT;
  if(canStandAt(nx,player.z,feet)||Math.abs(dx)<.0001)player.x=nx;
  if(canStandAt(player.x,nz,feet)||Math.abs(dz)<.0001)player.z=nz;
  player.vy-=19*dt;player.y+=player.vy*dt;
  const floor=highestAt(player.x,player.z)+1+EYE_HEIGHT;
  if(player.y<=floor){
    if(player.vy< -14){const damage=Math.min(8,Math.floor((-player.vy-12)*.55));player.health=Math.max(0,player.health-damage);if(damage)showToast(`Ouch! Fall damage: ${damage}`);}
    player.y=floor;player.vy=0;player.grounded=true;
  }else player.grounded=false;
  if(player.y< -10){player.y=floor;player.health=Math.max(1,player.health-3);}
  camera.position.set(player.x,player.y,player.z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
  hungerClock+=dt;if(hungerClock>42){hungerClock=0;player.hunger=Math.max(0,player.hunger-1);updateStats();}
  if(player.health<=0){player.health=12;player.hunger=Math.max(6,player.hunger);const h=highestAt(.5,.5);player.x=.5;player.z=.5;player.y=h+1+EYE_HEIGHT;player.vy=0;showToast('You woke up back at your starting point');updateStats();}
}
function updateTarget(){
  raycaster.setFromCamera(new THREE.Vector2(0,0),camera);
  const hits=raycaster.intersectObjects(meshes,false);
  if(!hits.length){currentTarget=null;outline.visible=false;ui.target.textContent='';return;}
  const hit=hits[0],p=hit.object.userData.positions[hit.instanceId];if(!p){currentTarget=null;outline.visible=false;return;}
  currentTarget={x:p.x,y:p.y,z:p.z,type:hit.object.userData.blockType,normal:hit.face?hit.face.normal.clone():new THREE.Vector3(0,1,0)};
  outline.position.set(p.x+.5,p.y+.5,p.z+.5);outline.visible=true;ui.target.textContent=BLOCKS[currentTarget.type]?.name||currentTarget.type;
}
function mineBlock(){
  if(!currentTarget||!running||paused)return;const {x,y,z,type}=currentTarget;if(type==='bedrock'){showToast('That block is too tough to break');return;}
  removeBlock(x,y,z);if(type!=='leaves')inventory[type]=(inventory[type]||0)+1;else if(Math.random()<.12)inventory.apple=(inventory.apple||0)+1;
  rebuildInstances();updateHotbar();updateInventory();showToast(`${BLOCKS[type]?.name||type} mined`);
}
function placeBlock(){
  if(!currentTarget||!running||paused)return;const type=HOTBAR[selectedSlot];if((inventory[type]||0)<=0){showToast(`No ${BLOCKS[type].name.toLowerCase()} left`);return;}
  const n=currentTarget.normal;const x=currentTarget.x+Math.round(n.x),y=currentTarget.y+Math.round(n.y),z=currentTarget.z+Math.round(n.z);
  if(getBlock(x,y,z)){showToast('There is already a block there');return;}
  const px=player.x,feet=player.y-EYE_HEIGHT,head=feet+1.8;
  if(px>=x-.3&&px<=x+1.3&&player.z>=z-.3&&player.z<=z+1.3&&y+1>feet&&y<head){showToast('You cannot place a block inside yourself');return;}
  if(y<1){showToast('The world has a bottom');return;}
  setBlock(x,y,z,type);inventory[type]--;rebuildInstances();updateHotbar();updateInventory();showToast(`${BLOCKS[type].name} placed`);
}
function updateHotbar(){
  ui.hotbar.innerHTML='';HOTBAR.forEach((type,i)=>{
    const slot=document.createElement('button');slot.className='hotbar-slot'+(selectedSlot===i?' selected':'');slot.title=BLOCKS[type].name;
    slot.innerHTML=`<span class="slot-number">${i+1}</span><span class="block-swatch" style="background:${BLOCKS[type].color}"></span><span class="slot-count">${inventory[type]||0}</span>`;
    slot.addEventListener('click',()=>{selectedSlot=i;updateHotbar();});ui.hotbar.appendChild(slot);
  });
}
function updateInventory(){
  if(!ui.inventoryGrid)return;ui.inventoryGrid.innerHTML='';
  const items=[...HOTBAR,'apple'];
  items.forEach(type=>{
    const count=inventory[type]||0;const b=document.createElement('button');b.className='inventory-item';
    const swatch=type==='apple'?'<span class="apple-swatch">🍎</span>':`<span class="block-swatch" style="background:${BLOCKS[type]?.color||'#aaa'}"></span>`;
    b.innerHTML=`${swatch}<span>${type==='apple'?'Apple':BLOCKS[type]?.name||type}</span><small>${count} owned</small>`;
    b.addEventListener('click',()=>{
      if(type==='apple'){if(count>0){inventory.apple--;player.hunger=Math.min(20,player.hunger+5);updateStats();updateInventory();showToast('You ate an apple (+5 hunger)');}else showToast('No apples to eat');return;}
      selectedSlot=Math.max(0,HOTBAR.indexOf(type));updateHotbar();showToast(`${BLOCKS[type].name} selected`);
    });ui.inventoryGrid.appendChild(b);
  });
}
function craft(output,cost,amount){
  const input=output==='planks'?'wood':'stone';if((inventory[input]||0)<cost){showToast(`Need ${cost} ${BLOCKS[input].name.toLowerCase()}`);return;}
  inventory[input]-=cost;inventory[output]=(inventory[output]||0)+amount;updateHotbar();updateInventory();showToast(`Crafted ${amount} ${BLOCKS[output].name.toLowerCase()}`);
}
function updateStats(){
  ui.healthValue.textContent=`${player.health} / 20`;ui.hungerValue.textContent=`${player.hunger} / 20`;
  ui.healthMeter.style.width=`${player.health/20*100}%`;ui.hungerMeter.style.width=`${player.hunger/20*100}%`;
}
function updateDayNight(dt){
  const old=dayClock;dayClock+=dt/240;if(dayClock>=1){dayClock-=1;dayNumber++;}
  const angle=dayClock*Math.PI*2-Math.PI/2;const sunY=Math.sin(angle);sunLight.position.set(Math.cos(angle)*35, sunY*42, -18);
  const daylight=THREE.MathUtils.smoothstep(sunY,-.24,.38);const sky=new THREE.Color('#101a31').lerp(new THREE.Color('#87c5ed'),daylight);
  const fog=new THREE.Color('#182333').lerp(new THREE.Color('#a8d7ef'),daylight);
  scene.background.copy(sky);scene.fog.color.copy(fog);sunLight.intensity=.12+daylight*2.1;ambientLight.intensity=.36+daylight*.98;
  water.material.color.setHex(daylight>.35?0x4b9fb3:0x233e5d);
  if(dayClock<old)showToast(`Day ${dayNumber}`);
  const total=Math.floor(dayClock*24),mins=Math.floor((dayClock*24-total)*60);
  ui.day.textContent=`DAY ${dayNumber}`;ui.time.textContent=`${String(total).padStart(2,'0')}:${String(mins).padStart(2,'0')}`;
}
function updateHud(){ui.pos.textContent=`${Math.floor(player.x)}, ${Math.floor(player.y-EYE_HEIGHT)}, ${Math.floor(player.z)}`;}
function showToast(message){ui.toast.textContent=message;ui.toast.classList.add('show');toastTimer=2.1;}
function animate(){
  if(!running)return;requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.04);
  if(!paused&&ui.inventory.classList.contains('hidden')){
    updatePlayer(dt);updateDayNight(dt);updateTarget();updateHud();saveClock+=dt;
    if(saveClock>40){saveClock=0;saveWorld();}
  }
  if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)ui.toast.classList.remove('show');}
  renderer.render(scene,camera);
}

// Start the renderer and show the title screen.
try{
  setupScene();
  // A tiny title-screen diorama, generated from the same block palette.
  generateWorld();rebuildInstances();
  camera.position.set(18,10,25);camera.lookAt(0,5,0);renderer.render(scene,camera);
  ui.loading.classList.add('hidden');ui.menu.classList.remove('hidden');
}catch(error){
  console.error(error);ui.loadingText.textContent='Could not start the 3D game. Try opening this page with an internet connection and a modern browser.';ui.loading.classList.remove('hidden');
}
