(() => {
  "use strict";
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const API_BASE = "https://www.googleapis.com/youtube/v3";
  const state = { key: localStorage.getItem("meldtube_api_key") || "", query: "", nextPage: null, videos: [], current: null, view: "home", history: readStore("meldtube_history", []), saved: readStore("meldtube_saved", []), busy: false };
  const sampleVideos = [
    {id:"jfKfPfyJRdk",title:"lofi hip hop radio 📚 - beats to relax / study to",channelTitle:"Lofi Girl",description:"Chill beats and a cozy study atmosphere.",publishedAt:"2024-01-01T00:00:00Z",thumbnail:"https://i.ytimg.com/vi/jfKfPfyJRdk/hqdefault.jpg"},
    {id:"aqz-KE-bpKQ",title:"Big Buck Bunny — Blender Open Movie",channelTitle:"Blender",description:"A short animated film made with Blender.",publishedAt:"2024-01-01T00:00:00Z",thumbnail:"https://i.ytimg.com/vi/aqz-KE-bpKQ/hqdefault.jpg"},
    {id:"ScMzIvxBSi4",title:"Relaxing nature and ambient scenery",channelTitle:"Nature",description:"A relaxing nature video.",publishedAt:"2024-01-01T00:00:00Z",thumbnail:"https://i.ytimg.com/vi/ScMzIvxBSi4/hqdefault.jpg"},
    {id:"kJQP7kiw5Fk",title:"Luis Fonsi — Despacito",channelTitle:"Luis Fonsi",description:"Official music video.",publishedAt:"2017-01-12T00:00:00Z",thumbnail:"https://i.ytimg.com/vi/kJQP7kiw5Fk/hqdefault.jpg"},
    {id:"ysz5S6PUM-U",title:"Sintel — Blender Open Movie",channelTitle:"Blender",description:"An open movie from the Blender Foundation.",publishedAt:"2024-01-01T00:00:00Z",thumbnail:"https://i.ytimg.com/vi/ysz5S6PUM-U/hqdefault.jpg"},
    {id:"L_jWHffIx5E",title:"Smash Mouth — All Star",channelTitle:"Smash Mouth",description:"Official music video.",publishedAt:"1999-01-01T00:00:00Z",thumbnail:"https://i.ytimg.com/vi/L_jWHffIx5E/hqdefault.jpg"}
  ];

  function readStore(key, fallback) { try { const v=JSON.parse(localStorage.getItem(key)); return Array.isArray(v)?v:fallback; } catch { return fallback; } }
  function escapeHTML(s="") { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function toast(message) { const el=$("#toast"); el.textContent=message; el.classList.add("show"); clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2600); }
  function shortDate(value) { if(!value)return ""; const d=new Date(value); if(Number.isNaN(+d))return ""; const days=Math.max(0,Math.floor((Date.now()-d.getTime())/86400000)); if(days<1)return "today"; if(days<30)return `${days} days ago`; if(days<365)return `${Math.floor(days/30)} months ago`; return `${Math.floor(days/365)} years ago`; }
  function formatCount(n) { if(n==null)return ""; n=Number(n); return n>=1e6?(n/1e6).toFixed(1)+"M views":n>=1000?(n/1000).toFixed(1)+"K views":n+" views"; }
  function normalizeItem(item) {
    const id = typeof item.id==="string" ? item.id : item.id?.videoId;
    return {id, title:item.snippet?.title||item.title||"Untitled video", channelTitle:item.snippet?.channelTitle||item.channelTitle||"YouTube creator", description:item.snippet?.description||item.description||"", publishedAt:item.snippet?.publishedAt||item.publishedAt||"", thumbnail:item.snippet?.thumbnails?.high?.url||item.snippet?.thumbnails?.medium?.url||item.snippet?.thumbnails?.default?.url||item.thumbnail||`https://i.ytimg.com/vi/${id}/hqdefault.jpg`, viewCount:item.statistics?.viewCount||item.viewCount||null};
  }
  function renderVideos(items, append=false) {
    const grid=$("#videoGrid");
    if(!append) grid.innerHTML="";
    if(!items.length && !append) {
      grid.innerHTML=`<div class="empty-state"><h3>Nothing here yet</h3><p>Try another search or use settings to connect YouTube search.</p><button class="secondary-btn" id="emptySettingsBtn">Open settings →</button></div>`;
      $("#emptySettingsBtn")?.addEventListener("click",openSettings); return;
    }
    const html=items.map(v=>{
      const saved=state.saved.some(x=>x.id===v.id);
      const thumb=escapeHTML(v.thumbnail || `https://i.ytimg.com/vi/${v.id}/hqdefault.jpg`);
      return `<article class="video-card" tabindex="0" role="button" aria-label="Play ${escapeHTML(v.title)}" data-play="${escapeHTML(v.id)}">
        <div class="thumbnail-wrap"><img class="thumbnail" src="${thumb}" alt="" loading="lazy" onerror="this.onerror=null;this.src='https://i.ytimg.com/vi/${encodeURIComponent(v.id)}/mqdefault.jpg'"><div class="play-overlay"><span>▶</span></div><span class="duration">▶ WATCH</span></div>
        <div class="card-info"><div class="channel-avatar">${escapeHTML((v.channelTitle||"M").slice(0,1).toUpperCase())}</div><div class="card-copy"><h3 class="video-title">${escapeHTML(v.title)}</h3><div class="channel-name">${escapeHTML(v.channelTitle)}</div><div class="video-stats">${escapeHTML(v.viewCount?formatCount(v.viewCount):shortDate(v.publishedAt))}</div></div><button class="save-btn ${saved?"saved":""}" data-save="${escapeHTML(v.id)}" title="${saved?"Remove saved video":"Save video"}" aria-label="Save video">${saved?"♥":"♡"}</button></div>
      </article>`;
    }).join("");
    grid.insertAdjacentHTML(append?"beforeend":"beforeend",html);
    $("#resultCount").textContent=`${state.videos.length} videos`;
  }
  function setVideos(items, append=false) {
    const normalized=items.map(normalizeItem).filter(v=>v.id);
    state.videos=append?[...state.videos,...normalized]:normalized;
    renderVideos(normalized,append);
  }
  async function youtubeSearch(query, append=false) {
    if(!state.key) {
      state.query=query;
      $("#sectionTitle").textContent=query?`Search: ${query}`:"Explore videos";
      $("#notice").hidden=false;
      const url=query?`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`:"https://www.youtube.com";
      if(query) {
        renderVideos([],false);
        $("#videoGrid").innerHTML=`<div class="empty-state"><h3>Search needs a YouTube API key</h3><p>For in-page results, add a YouTube Data API v3 key in settings. You can also open your search directly on YouTube.</p><p><button class="primary-btn" id="openYtSearch">Search on YouTube ↗</button> <button class="secondary-btn" id="setupKeyBtn">Set up API key</button></p></div>`;
        $("#openYtSearch").onclick=()=>window.open(url,"_blank","noopener,noreferrer");
        $("#setupKeyBtn").onclick=openSettings;
      } else { setVideos(sampleVideos); }
      $("#loadMoreBtn").hidden=true;
      return;
    }
    if(state.busy)return;
    state.busy=true;
    state.query=query;
    $("#sectionTitle").textContent=query?`Results for “${query}”`:"Explore videos";
    $("#notice").hidden=true;
    if(!append) $("#videoGrid").innerHTML=Array.from({length:6},()=>'<div class="skeleton"></div>').join("");
    try {
      const params=new URLSearchParams({part:"snippet",type:"video",maxResults:"18",q:query||"popular videos",safeSearch:"moderate",key:state.key});
      if(append&&state.nextPage)params.set("pageToken",state.nextPage);
      const response=await fetch(`${API_BASE}/search?${params.toString()}`);
      const data=await response.json();
      if(!response.ok) throw new Error(data.error?.message||"YouTube search failed. Check the API key and quota.");
      state.nextPage=data.nextPageToken||null;
      setVideos(data.items||[],append);
      $("#loadMoreBtn").hidden=!state.nextPage;
      if(!append&&!query) $("#notice").hidden=true;
    } catch(err) {
      if(!append) $("#videoGrid").innerHTML="";
      $("#videoGrid").innerHTML=`<div class="empty-state"><h3>Couldn’t load videos</h3><p>${escapeHTML(err.message)} Make sure YouTube Data API v3 is enabled and your key is valid.</p><button class="secondary-btn" id="retrySearchBtn">Try again ↻</button></div>`;
      $("#retrySearchBtn").onclick=()=>youtubeSearch(state.query);
      $("#loadMoreBtn").hidden=true;
    } finally {state.busy=false;}
  }
  function getVideoId(input) {
    const raw=(input||"").trim(); if(/^[\w-]{11}$/.test(raw))return raw;
    try {const u=new URL(raw); if(u.hostname.endsWith("youtu.be"))return u.pathname.split("/").filter(Boolean)[0]||null; if(u.hostname.includes("youtube.com"))return u.searchParams.get("v")||u.pathname.match(/\/(?:embed|shorts|live)\/([\w-]{11})/)?.[1]||null;}catch{}
    return null;
  }
  function playVideo(videoOrId) {
    const video=typeof videoOrId==="string"?(state.videos.find(v=>v.id===videoOrId)||state.saved.find(v=>v.id===videoOrId)||sampleVideos.map(normalizeItem).find(v=>v.id===videoOrId)||{id:videoOrId,title:"YouTube video",channelTitle:"YouTube"}):videoOrId;
    if(!video?.id){toast("That doesn't look like a valid YouTube URL or video ID.");return;}
    state.current=video;
    $("#playerTitle").textContent=video.title||"YouTube video";
    $("#playerMeta").textContent=`${video.channelTitle||"YouTube"} · Playing through YouTube`;
    $("#playerFrameWrap").innerHTML=`<iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(video.id)}?autoplay=1&rel=0" title="${escapeHTML(video.title||"YouTube video")}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`;
    $("#playerModal").hidden=false; document.body.style.overflow="hidden";
    const wasSaved=state.saved.some(v=>v.id===video.id); $("#saveCurrentBtn").textContent=wasSaved?"♥ Saved":"♡ Save";
    state.history=[video,...state.history.filter(v=>v.id!==video.id)].slice(0,100); localStorage.setItem("meldtube_history",JSON.stringify(state.history));
  }
  function closeModal(id) { const modal=$("#"+id); if(!modal)return; modal.hidden=true; if(id==="playerModal")$("#playerFrameWrap").innerHTML=""; if(!$$(".modal-backdrop").some(m=>!m.hidden))document.body.style.overflow=""; }
  function openSettings() { $("#apiKeyInput").value=state.key; $("#settingsStatus").textContent=""; $("#settingsModal").hidden=false; document.body.style.overflow="hidden"; }
  function toggleSave(id) {
    const video=state.videos.find(v=>v.id===id)||state.history.find(v=>v.id===id)||sampleVideos.map(normalizeItem).find(v=>v.id===id)||{id,title:"YouTube video",channelTitle:"YouTube",thumbnail:`https://i.ytimg.com/vi/${id}/hqdefault.jpg`};
    const exists=state.saved.some(v=>v.id===id);
    state.saved=exists?state.saved.filter(v=>v.id!==id):[video,...state.saved];
    localStorage.setItem("meldtube_saved",JSON.stringify(state.saved));
    $$(`[data-save="${CSS.escape(id)}"]`).forEach(btn=>{btn.classList.toggle("saved",!exists);btn.textContent=exists?"♡":"♥";btn.title=exists?"Save video":"Remove saved video";});
    if($("#saveCurrentBtn")&&state.current?.id===id)$("#saveCurrentBtn").textContent=exists?"♡ Save":"♥ Saved";
    toast(exists?"Removed from saved videos":"Saved for later");
    if(state.view==="saved")showLocalList("saved");
  }
  function showLocalList(type) {
    state.view=type; $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===type));
    $("#hero").hidden=true; $("#chips").hidden=true; $("#notice").hidden=true;
    const list=type==="history"?state.history:state.saved;
    $("#sectionTitle").textContent=type==="history"?"Watch history":"Saved videos";
    $("#videoGrid").innerHTML="";
    state.videos=list; renderVideos(list);
    if(!list.length)$("#videoGrid").innerHTML=`<div class="empty-state"><h3>${type==="history"?"No watch history yet":"No saved videos yet"}</h3><p>Videos you ${type==="history"?"watch":"save"} will show up here on this device.</p><button class="secondary-btn" id="backHomeBtn">Back to Home →</button></div>`;
    $("#backHomeBtn")?.addEventListener("click",goHome);
    $("#loadMoreBtn").hidden=true; $("#resultCount").textContent=`${list.length} videos`;
  }
  function goHome() {
    state.view="home"; $("#hero").hidden=false; $("#chips").hidden=false; $("#notice").hidden=!state.key;
    $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view==="home"));
    youtubeSearch("");
  }

  $("#searchForm").addEventListener("submit",e=>{e.preventDefault(); const q=$("#searchInput").value.trim(); if(!q)return; state.view="search"; $("#hero").hidden=true; $("#chips").hidden=false; $$(".nav-item").forEach(b=>b.classList.remove("active")); youtubeSearch(q);});
  $("#homeLink").addEventListener("click",e=>{e.preventDefault();$("#searchInput").value="";goHome();});
  $("#exploreBtn").addEventListener("click",()=>{document.querySelector(".section-heading").scrollIntoView({behavior:"smooth",block:"start"});youtubeSearch("");});
  $("#settingsBtn").addEventListener("click",openSettings); $("#avatarBtn").addEventListener("click",e=>{e.preventDefault();openSettings();}); $("#noticeSettings").addEventListener("click",openSettings);
  $("#saveSettingsBtn").addEventListener("click",()=>{state.key=$("#apiKeyInput").value.trim();if(state.key)localStorage.setItem("meldtube_api_key",state.key);else localStorage.removeItem("meldtube_api_key");$("#settingsStatus").textContent=state.key?"API key saved in this browser.":"API key cleared.";toast(state.key?"YouTube search connected":"API key cleared");closeModal("settingsModal");if(state.query)youtubeSearch(state.query);else youtubeSearch("");});
  $("#clearKeyBtn").addEventListener("click",()=>{$("#apiKeyInput").value="";state.key="";localStorage.removeItem("meldtube_api_key");$("#settingsStatus").textContent="API key removed from this browser.";});
  $("#playUrlBtn").addEventListener("click",()=>{const id=getVideoId($("#videoUrlInput").value);if(!id){$("#settingsStatus").textContent="Enter a valid YouTube URL or 11-character video ID.";return;}closeModal("settingsModal");playVideo(id);});
  $("#videoUrlInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("#playUrlBtn").click();});
  $("#loadMoreBtn").addEventListener("click",()=>youtubeSearch(state.query,true));
  $("#saveCurrentBtn").addEventListener("click",()=>{if(state.current)toggleSave(state.current.id);});
  $("#historyBtn").addEventListener("click",()=>showLocalList("history")); $("#savedBtn").addEventListener("click",()=>showLocalList("saved"));
  $$(".nav-item[data-view]").forEach(btn=>btn.addEventListener("click",()=>{const view=btn.dataset.view;if(view==="home"){goHome();return;} if(["popular","music","gaming","learning"].includes(view)){state.view=view;$("#hero").hidden=true;$("#chips").hidden=false;$$(".nav-item").forEach(b=>b.classList.toggle("active",b===btn));$("#searchInput").value="";const q=view==="popular"?"popular videos":view; $$(".chip").forEach(c=>c.classList.toggle("selected",c.dataset.query===q));youtubeSearch(q);}}));
  $$(".chip").forEach(chip=>chip.addEventListener("click",()=>{$$(".chip").forEach(c=>c.classList.toggle("selected",c===chip));const q=chip.dataset.query||"";$("#searchInput").value=q;state.view="search";$("#hero").hidden=true;youtubeSearch(q);}));
  $("#videoGrid").addEventListener("click",e=>{const save=e.target.closest("[data-save]");if(save){e.stopPropagation();toggleSave(save.dataset.save);return;}const card=e.target.closest("[data-play]");if(card)playVideo(card.dataset.play);});
  $("#videoGrid").addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.matches("[data-play]")){e.preventDefault();playVideo(e.target.dataset.play);}});
  $$(".close-modal").forEach(btn=>btn.addEventListener("click",()=>closeModal(btn.dataset.close)));
  $$(".modal-backdrop").forEach(modal=>modal.addEventListener("click",e=>{if(e.target===modal)closeModal(modal.id);}));
  document.addEventListener("keydown",e=>{if(e.key==="Escape")$$(".modal-backdrop").filter(m=>!m.hidden).forEach(m=>closeModal(m.id));});
  $("#menuToggle").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
  document.addEventListener("click",e=>{if(window.innerWidth<=760&&!e.target.closest("#sidebar")&&!e.target.closest("#menuToggle"))$("#sidebar").classList.remove("open");});
  $("#notice").hidden=!!state.key;
  if(state.key)youtubeSearch("");else setVideos(sampleVideos);
})();